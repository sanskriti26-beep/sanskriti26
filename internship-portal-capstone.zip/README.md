# LaunchPad Internship Portal

A polished full-stack internship portal built with Node.js, Express, SQLite, and vanilla HTML/CSS/JavaScript.

## Features
- Responsive, mobile-first user journey
- Search, domain filter, work-mode filter, pagination
- Accessible labels, focusable controls, live status messages, semantic HTML
- Secure API defaults with Helmet, rate limiting, JSON size limits, prepared SQL statements
- Server-side application validation and normalized input
- Structured JSON logs and `/health` endpoint
- Automated regression tests with Node's built-in test runner

## Run locally
```bash
npm install
npm start
```
Open `http://localhost:3000`.

Run tests while the server is running:
```bash
npm test
```

## API
- `GET /health`
- `GET /api/internships?page=1&limit=6&search=react&domain=Web%20Development&mode=Hybrid`
- `GET /api/internships/:id`
- `POST /api/applications`

## Engineering decisions
1. SQLite keeps setup beginner-friendly while using real persistence.
2. Prepared statements prevent SQL injection and keep query intent explicit.
3. Server validation is authoritative; client validation only improves feedback speed.
4. Pagination limits payload size and creates a path to larger datasets.
5. Helmet, rate limiting, body-size limits, and disabled `x-powered-by` reduce common attack surface.
6. The frontend uses progressive loading states and empty/error states so users always receive feedback.
7. Vanilla JavaScript avoids a build step and makes deployment easy on beginner-friendly hosts.

## QA evidence
- `tests/api.test.js`: health, pagination, and invalid application regression checks.
- Accessibility: semantic landmarks, visible controls, labels, keyboard-friendly modal, live status region.
- Performance: small dependency footprint, no framework bundle, limited API payloads, responsive CSS.
- Security: `npm audit --omit=dev`, Helmet, rate limiting, parameterized SQL, validation, and bounded input lengths.

## Deployment
Deploy to Render, Railway, Fly.io, or another Node-compatible host. Set `PORT` automatically from the host. For persistent SQLite on ephemeral hosts, attach a persistent disk or replace SQLite with PostgreSQL.

## Walkthrough video
Record a 2–4 minute screen capture showing:
1. Mobile and desktop layout
2. Search and filters
3. Opening and submitting the application form
4. `/health` response
5. Test command and repository README

Add the final video URL here:
`VIDEO_LINK_HERE`
