import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB_FILE || "internships.db");

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS internships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  company TEXT NOT NULL,
  location TEXT NOT NULL,
  mode TEXT NOT NULL,
  domain TEXT NOT NULL,
  duration TEXT NOT NULL,
  stipend TEXT NOT NULL,
  description TEXT NOT NULL,
  skills TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  internship_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  resume_url TEXT NOT NULL,
  cover_note TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (internship_id) REFERENCES internships(id)
);
`);

const count = db.prepare("SELECT COUNT(*) AS count FROM internships").get().count;
if (!count) {
  const seed = [
    ["Frontend Developer Intern","BrightLabs","Delhi, India","Hybrid","Web Development","3 months","₹10,000/month","Build accessible, responsive interfaces for a growing education platform.","HTML, CSS, JavaScript, React"],
    ["Backend Engineering Intern","DataNest","Remote","Remote","Backend Development","4 months","₹15,000/month","Create reliable APIs, database queries, and automated tests.","Node.js, Express, SQL, REST"],
    ["UI/UX Design Intern","PixelCraft","Bengaluru, India","On-site","Design","2 months","₹8,000/month","Turn user research into clear flows, wireframes, and polished product screens.","Figma, Research, Prototyping"],
    ["Data Analyst Intern","InsightLoop","Mumbai, India","Hybrid","Data Science","3 months","₹12,000/month","Explore business data and communicate insights through dashboards.","Excel, SQL, Python, Power BI"]
  ];
  const insert = db.prepare(`INSERT INTO internships
    (title,company,location,mode,domain,duration,stipend,description,skills)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  const transaction = db.transaction(rows => rows.forEach(row => insert.run(...row)));
  transaction(seed);
}

app.disable("x-powered-by");
app.use(helmet({ crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));

function log(event, details = {}) {
  console.log(JSON.stringify({ time: new Date().toISOString(), event, ...details }));
}
function validEmail(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); }
function clean(value, max = 500) { return String(value ?? "").trim().slice(0, max); }

app.get("/health", (_req, res) => res.json({ status: "ok", service: "internship-portal", timestamp: new Date().toISOString() }));

app.get("/api/internships", (req, res) => {
  const page = Math.max(1, Number.parseInt(req.query.page || "1", 10));
  const limit = Math.min(20, Math.max(1, Number.parseInt(req.query.limit || "6", 10)));
  const search = clean(req.query.search, 80);
  const domain = clean(req.query.domain, 80);
  const mode = clean(req.query.mode, 40);
  const where = [];
  const params = {};
  if (search) { where.push("(title LIKE @search OR company LIKE @search OR skills LIKE @search)"); params.search = `%${search}%`; }
  if (domain) { where.push("domain = @domain"); params.domain = domain; }
  if (mode) { where.push("mode = @mode"); params.mode = mode; }
  const clause = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const total = db.prepare(`SELECT COUNT(*) AS count FROM internships ${clause}`).get(params).count;
  const rows = db.prepare(`SELECT * FROM internships ${clause} ORDER BY id DESC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit, offset: (page - 1) * limit })
    .map(row => ({ ...row, skills: row.skills.split(", ") }));
  res.json({ data: rows, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

app.get("/api/internships/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM internships WHERE id = ?").get(Number(req.params.id));
  if (!row) return res.status(404).json({ error: "Internship not found" });
  row.skills = row.skills.split(", ");
  res.json({ data: row });
});

app.post("/api/applications", (req, res) => {
  const body = req.body || {};
  const internshipId = Number(body.internship_id);
  const name = clean(body.name, 80);
  const email = clean(body.email, 120).toLowerCase();
  const phone = clean(body.phone, 30);
  const resumeUrl = clean(body.resume_url, 300);
  const coverNote = clean(body.cover_note, 1200);
  const errors = {};
  if (!Number.isInteger(internshipId) || internshipId < 1) errors.internship_id = "Choose a valid internship.";
  if (name.length < 2) errors.name = "Name must contain at least 2 characters.";
  if (!validEmail(email)) errors.email = "Enter a valid email address.";
  if (!/^[0-9+\-\s()]{7,20}$/.test(phone)) errors.phone = "Enter a valid phone number.";
  if (!/^https?:\/\/\S+$/i.test(resumeUrl)) errors.resume_url = "Resume URL must start with http:// or https://.";
  if (coverNote.length < 20) errors.cover_note = "Cover note must contain at least 20 characters.";
  const internship = db.prepare("SELECT id FROM internships WHERE id = ?").get(internshipId);
  if (!internship) errors.internship_id = "Selected internship does not exist.";
  if (Object.keys(errors).length) return res.status(400).json({ error: "Validation failed", fields: errors });

  const result = db.prepare(`INSERT INTO applications
    (internship_id,name,email,phone,resume_url,cover_note) VALUES (?,?,?,?,?,?)`)
    .run(internshipId, name, email, phone, resumeUrl, coverNote);
  log("application_created", { applicationId: result.lastInsertRowid, internshipId });
  res.status(201).json({ message: "Application submitted successfully", applicationId: result.lastInsertRowid });
});

app.use(express.static(path.join(__dirname, "public")));
app.use((err, _req, res, _next) => {
  log("request_error", { message: err.message });
  res.status(500).json({ error: "Unexpected server error" });
});

app.listen(PORT, () => log("server_started", { port: PORT }));
