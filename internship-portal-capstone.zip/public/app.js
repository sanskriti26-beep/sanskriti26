const $ = (s) => document.querySelector(s);
let page = 1, pages = 1, current = [];
const status = $("#status");
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
async function load(){
  status.textContent="Loading opportunities…"; $("#cards").innerHTML="";
  const params=new URLSearchParams({page,limit:6,search:$("#search").value,domain:$("#domain").value,mode:$("#mode").value});
  try{
    const res=await fetch(`/api/internships?${params}`); if(!res.ok) throw new Error();
    const json=await res.json(); current=json.data; pages=json.pagination.pages||1;
    $("#result-count").textContent=`${json.pagination.total} opportunity${json.pagination.total===1?"":"ies"}`;
    $("#page-label").textContent=`Page ${page} of ${pages}`; $("#prev").disabled=page<=1; $("#next").disabled=page>=pages;
    status.textContent=current.length?"":"No internships match your filters.";
    $("#cards").innerHTML=current.map(i=>`<article class="card"><span class="tag">${escapeHTML(i.domain)}</span><h3>${escapeHTML(i.title)}</h3><strong>${escapeHTML(i.company)}</strong><div class="meta"><span>📍 ${escapeHTML(i.location)}</span><span>◷ ${escapeHTML(i.duration)}</span><span>💼 ${escapeHTML(i.mode)}</span></div><p>${escapeHTML(i.description)}</p><div class="skills">${i.skills.map(escapeHTML).join(" · ")}</div><button class="button primary apply" data-id="${i.id}">View & apply</button></article>`).join("");
    document.querySelectorAll(".apply").forEach(b=>b.onclick=()=>openModal(current.find(i=>i.id==b.dataset.id)));
  }catch{status.textContent="Could not load opportunities. Please try again.";}}
function openModal(i){$("#modal").hidden=false;$("#internship_id").value=i.id;$("#selected-role").textContent=`${i.title} · ${i.company}`;$("#name").focus();}
function closeModal(){$("#modal").hidden=true;$("#form-error").textContent="";$("#application-form").reset();}
$("#search").oninput=()=>{page=1;load()}; $("#domain").onchange=()=>{page=1;load()}; $("#mode").onchange=()=>{page=1;load()}; $("#clear").onclick=()=>{$("#search").value="";$("#domain").value="";$("#mode").value="";page=1;load()}; $("#prev").onclick=()=>{page--;load()}; $("#next").onclick=()=>{page++;load()}; $("#close").onclick=closeModal; $("#modal").onclick=e=>{if(e.target.id==="modal")closeModal()};
$("#application-form").onsubmit=async e=>{e.preventDefault();$("#form-error").textContent="Submitting…";const body=Object.fromEntries(new FormData(e.target));body.internship_id=Number(body.internship_id);const res=await fetch("/api/applications",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const data=await res.json();if(!res.ok){$("#form-error").textContent=Object.values(data.fields||{}).join(" ");return;}alert("Application submitted successfully!");closeModal();};
load();
