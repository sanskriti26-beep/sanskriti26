# QA Checklist

- [ ] Test desktop layout at 1440px
- [ ] Test mobile layout at 390px
- [ ] Search returns matching results
- [ ] Filters can be combined
- [ ] Empty state is understandable
- [ ] API error state offers a retry path
- [ ] Application form rejects invalid data
- [ ] Successful application is persisted
- [ ] Keyboard navigation works
- [ ] Run `npm test`
- [ ] Run `npm audit --omit=dev`
- [ ] Run Lighthouse and record Performance, Accessibility, Best Practices, and SEO scores
- [ ] Record walkthrough video
- [ ] Deploy and paste live URL in README
