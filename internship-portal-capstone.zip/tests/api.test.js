import test from "node:test";
import assert from "node:assert/strict";

const base = "http://localhost:3000";
test("health endpoint returns ok", async () => {
  const response = await fetch(`${base}/health`);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.status, "ok");
});
test("internship list supports pagination", async () => {
  const response = await fetch(`${base}/api/internships?page=1&limit=2`);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.data.length, 2);
  assert.equal(body.pagination.limit, 2);
});
test("application validation rejects incomplete data", async () => {
  const response = await fetch(`${base}/api/applications`, {
    method: "POST", headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ internship_id: 1, name: "A", email: "bad", phone: "x", resume_url: "file", cover_note: "short" })
  });
  assert.equal(response.status, 400);
  const body = await response.json();
  assert.ok(body.fields.email);
});
