# Security Notes

- Inputs are trimmed and length-bounded before persistence.
- Email, phone, URL, and required text fields are validated on the server.
- SQL uses prepared statements rather than string interpolation.
- Helmet sets protective HTTP headers.
- Rate limiting protects API routes from basic abuse.
- Request bodies are capped at 20 KB.
- Production deployments should use HTTPS, environment-based secrets, persistent database storage, and centralized logs.
