const db = require('./database');
const records = [
  ['Frontend Developer Intern','TechNova Solutions','Delhi','Hybrid','Build responsive web interfaces and reusable UI components.','HTML, CSS, JavaScript, React',10000,'3 months','https://example.com/apply/frontend'],
  ['Backend Developer Intern','CodeCraft Labs','Bengaluru','Remote','Build REST APIs and work with relational databases.','Node.js, Express, SQL',12000,'4 months','https://example.com/apply/backend'],
  ['Data Analyst Intern','InsightWorks','Mumbai','On-site','Analyze business data and prepare useful reports.','Excel, SQL, Python',8000,'3 months','https://example.com/apply/data'],
  ['Full Stack Developer Intern','WebWorks','Noida','Remote','Develop and test full-stack web applications.','JavaScript, Node.js, Express, SQLite',15000,'6 months','https://example.com/apply/fullstack']
];
const insert = db.prepare(`INSERT INTO internships (title,company,location,mode,description,skills,stipend,duration,application_url) VALUES (?,?,?,?,?,?,?,?,?)`);
db.transaction(() => { db.prepare('DELETE FROM internships').run(); records.forEach(r => insert.run(...r)); })();
console.log('Seed data inserted successfully.');
