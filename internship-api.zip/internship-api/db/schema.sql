CREATE TABLE IF NOT EXISTS internships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  company TEXT NOT NULL,
  location TEXT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('Remote', 'On-site', 'Hybrid')),
  description TEXT NOT NULL,
  skills TEXT NOT NULL,
  stipend INTEGER NOT NULL DEFAULT 0 CHECK (stipend >= 0),
  duration TEXT NOT NULL,
  application_url TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
