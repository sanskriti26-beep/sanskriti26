# Internship Records API

A beginner-friendly REST API for internship records using Node.js, Express, and SQLite.

## Features
- CRUD operations
- Server-side validation
- Consistent JSON responses and status codes
- Pagination (`page` and `limit`)
- SQLite persistence
- Seed data

## Setup
```bash
npm install
npm run seed
npm run dev
```
Open `http://localhost:3000`.

## Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/internships?page=1&limit=10` | List records |
| GET | `/api/internships/:id` | Get one record |
| POST | `/api/internships` | Create record |
| PUT | `/api/internships/:id` | Replace record |
| DELETE | `/api/internships/:id` | Delete record |

## Example POST body
```json
{
  "title":"Full Stack Developer Intern",
  "company":"WebWorks",
  "location":"Noida",
  "mode":"Remote",
  "description":"Develop and test full-stack web applications.",
  "skills":"JavaScript, Node.js, Express, SQLite",
  "stipend":15000,
  "duration":"6 months",
  "application_url":"https://example.com/apply"
}
```

## Status codes
- `200` successful read/update/delete
- `201` created
- `400` validation or invalid JSON
- `404` resource/route not found
- `500` server error

## Database schema
See `db/schema.sql`. The SQLite database file is created automatically and is ignored by Git.
