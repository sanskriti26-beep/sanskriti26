const express = require('express');
const db = require('../db/database');
const router = express.Router();
const modes = ['Remote', 'On-site', 'Hybrid'];

function validate(data) {
  const errors = {};
  const required = ['title','company','location','description','skills','duration'];
  required.forEach(field => { if (typeof data[field] !== 'string' || data[field].trim().length < 2) errors[field] = `${field} is required and must contain at least 2 characters.`; });
  if (!modes.includes(data.mode)) errors.mode = 'mode must be Remote, On-site, or Hybrid.';
  if (data.stipend !== undefined && (!Number.isInteger(data.stipend) || data.stipend < 0)) errors.stipend = 'stipend must be a non-negative integer.';
  if (data.application_url !== undefined && data.application_url !== null && data.application_url !== '' && !/^https?:\/\//i.test(data.application_url)) errors.application_url = 'application_url must be a valid http or https URL.';
  return errors;
}
function clean(data) { return {...data, title:data.title.trim(), company:data.company.trim(), location:data.location.trim(), description:data.description.trim(), skills:data.skills.trim(), duration:data.duration.trim(), stipend:data.stipend ?? 0, application_url:data.application_url || null}; }

router.get('/', (req,res) => {
  const page = Math.max(parseInt(req.query.page,10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit,10) || 10, 1), 50);
  const total = db.prepare('SELECT COUNT(*) AS count FROM internships').get().count;
  const data = db.prepare('SELECT * FROM internships ORDER BY id DESC LIMIT ? OFFSET ?').all(limit, (page-1)*limit);
  res.json({success:true,data,pagination:{page,limit,total,totalPages:Math.ceil(total/limit)}});
});
router.get('/:id', (req,res) => {
  const data = db.prepare('SELECT * FROM internships WHERE id=?').get(req.params.id);
  if (!data) return res.status(404).json({success:false,error:'Internship not found.'});
  res.json({success:true,data});
});
router.post('/', (req,res) => {
  const errors = validate(req.body);
  if (Object.keys(errors).length) return res.status(400).json({success:false,errors});
  const d = clean(req.body);
  const result = db.prepare(`INSERT INTO internships (title,company,location,mode,description,skills,stipend,duration,application_url) VALUES (?,?,?,?,?,?,?,?,?)`).run(d.title,d.company,d.location,d.mode,d.description,d.skills,d.stipend,d.duration,d.application_url);
  const data = db.prepare('SELECT * FROM internships WHERE id=?').get(result.lastInsertRowid);
  res.status(201).json({success:true,message:'Internship created successfully.',data});
});
router.put('/:id', (req,res) => {
  if (!db.prepare('SELECT id FROM internships WHERE id=?').get(req.params.id)) return res.status(404).json({success:false,error:'Internship not found.'});
  const errors = validate(req.body);
  if (Object.keys(errors).length) return res.status(400).json({success:false,errors});
  const d = clean(req.body);
  db.prepare(`UPDATE internships SET title=?,company=?,location=?,mode=?,description=?,skills=?,stipend=?,duration=?,application_url=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(d.title,d.company,d.location,d.mode,d.description,d.skills,d.stipend,d.duration,d.application_url,req.params.id);
  res.json({success:true,message:'Internship updated successfully.',data:db.prepare('SELECT * FROM internships WHERE id=?').get(req.params.id)});
});
router.delete('/:id', (req,res) => {
  const result = db.prepare('DELETE FROM internships WHERE id=?').run(req.params.id);
  if (!result.changes) return res.status(404).json({success:false,error:'Internship not found.'});
  res.json({success:true,message:'Internship deleted successfully.'});
});
module.exports = router;
