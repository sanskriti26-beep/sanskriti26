# Security Checklist

- Helmet adds secure HTTP response headers.
- Express JSON body size is limited to 10 KB.
- API requests are rate-limited to 100 requests per 15 minutes.
- SQL statements use prepared/parameterized queries.
- Server-side validation is applied to every application.
- User input is trimmed and length-limited.
- HTML output is escaped in the frontend.
- Application records are stored in SQLite.
- No secrets are committed; configure environment variables outside source control.
- In production, use HTTPS, a managed database, logging, backups, and stricter origin/CORS policy.
