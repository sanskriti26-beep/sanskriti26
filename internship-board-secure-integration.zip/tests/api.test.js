import test from "node:test";
import assert from "node:assert/strict";
import { validateApplication } from "../server.js";

test("rejects invalid application data", () => {
  const result = validateApplication({name:"A",email:"wrong",phone:"x",coverLetter:"short"});
  assert.ok(Object.keys(result.errors).length >= 4);
});
test("accepts valid application data", () => {
  const result = validateApplication({name:"Sanskriti",email:"test@example.com",phone:"+91 9876543210",coverLetter:"I am excited to apply for this internship opportunity."});
  assert.deepEqual(result.errors, {});
});
test("normalizes safe input", () => {
  const result = validateApplication({name:"  Jane Doe  ",email:" JANE@EXAMPLE.COM ",phone:"1234567890",coverLetter:"This is a sufficiently long cover letter."});
  assert.equal(result.data.name,"Jane Doe");
  assert.equal(result.data.email,"jane@example.com");
});
