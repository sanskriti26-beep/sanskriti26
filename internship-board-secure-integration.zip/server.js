import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database(process.env.DB_FILE || "internships.db");

db.exec(`
CREATE TABLE IF NOT EXISTS internships (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  company TEXT NOT NULL,
  domain TEXT NOT NULL,
  location TEXT NOT NULL,
  duration TEXT NOT NULL,
  type TEXT NOT NULL,
  description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  internship_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  cover_letter TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (internship_id) REFERENCES internships(id)
);
`);

const count = db.prepare("SELECT COUNT(*) AS count FROM internships").get().count;
if (count === 0) {
  const insert = db.prepare(`INSERT INTO internships
    (id,title,company,domain,location,duration,type,description)
    VALUES (@id,@title,@company,@domain,@location,@duration,@type,@description)`);
  const seed = [
    [1,"Frontend Developer Intern","TechNova","Web Development","Remote","3 months","Paid","Build accessible interfaces with HTML, CSS, and JavaScript."],
    [2,"Backend Developer Intern","CodeWorks","Web Development","Delhi","6 months","Paid","Create APIs and work with databases and server-side JavaScript."],
    [3,"Data Analyst Intern","DataSphere","Data Science","Remote","3 months","Paid","Explore datasets and create useful business insights."],
    [4,"UI/UX Design Intern","CreativeLabs","Design","Mumbai","4 months","Unpaid","Design user flows, wireframes, and accessible experiences."],
    [5,"Python Developer Intern","InnovateTech","Programming","Bengaluru","6 months","Paid","Develop automation tools and backend services with Python."],
    [6,"Digital Marketing Intern","MarketPro","Marketing","Remote","3 months","Paid","Support campaigns, content planning, and performance analysis."]
  ];
  const transaction=db.transaction(rows=>rows.forEach(row=>insert.run({
    id:row[0],title:row[1],company:row[2],domain:row[3],location:row[4],
    duration:row[5],type:row[6],description:row[7]
  })));
  transaction(seed);
}

app.use(helmet());
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 100,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." }
});
app.use("/api", apiLimiter);

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}
function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function validateApplication(body) {
  const data = {
    name: clean(body.name),
    email: clean(body.email).toLowerCase(),
    phone: clean(body.phone),
    coverLetter: clean(body.coverLetter)
  };
  const errors = {};
  if (data.name.length < 2 || data.name.length > 80) errors.name = "Name must be 2–80 characters.";
  if (!validEmail(data.email) || data.email.length > 160) errors.email = "Enter a valid email address.";
  if (!/^[0-9+()\-\s]{7,20}$/.test(data.phone)) errors.phone = "Enter a valid phone number.";
  if (data.coverLetter.length < 20 || data.coverLetter.length > 2000) errors.coverLetter = "Cover letter must be 20–2000 characters.";
  return { data, errors };
}

app.get("/api/internships", (req,res)=>{
  const page=Math.max(Number.parseInt(req.query.page || "1",10),1);
  const limit=Math.min(Math.max(Number.parseInt(req.query.limit || "6",10),1),50);
  const search=clean(req.query.search);
  const domain=clean(req.query.domain);
  const location=clean(req.query.location);
  const where=[]; const params={};
  if(search){ where.push("(title LIKE @search OR company LIKE @search OR domain LIKE @search)"); params.search=`%${search}%`; }
  if(domain && domain!=="all"){ where.push("domain = @domain"); params.domain=domain; }
  if(location && location!=="all"){ where.push("location = @location"); params.location=location; }
  const clause=where.length ? `WHERE ${where.join(" AND ")}` : "";
  const total=db.prepare(`SELECT COUNT(*) AS count FROM internships ${clause}`).get(params).count;
  const rows=db.prepare(`SELECT * FROM internships ${clause} ORDER BY id LIMIT @limit OFFSET @offset`)
    .all({...params,limit,offset:(page-1)*limit});
  res.json({data:rows, pagination:{page,limit,total,totalPages:Math.ceil(total/limit)}});
});

app.get("/api/internships/:id",(req,res)=>{
  const id=Number.parseInt(req.params.id,10);
  if(!Number.isInteger(id)) return res.status(400).json({error:"Invalid internship id."});
  const row=db.prepare("SELECT * FROM internships WHERE id = ?").get(id);
  if(!row) return res.status(404).json({error:"Internship not found."});
  res.json(row);
});

app.post("/api/applications",(req,res)=>{
  const internshipId=Number.parseInt(req.body.internshipId,10);
  if(!Number.isInteger(internshipId)) return res.status(400).json({error:"Invalid internship id."});
  const internship=db.prepare("SELECT id FROM internships WHERE id = ?").get(internshipId);
  if(!internship) return res.status(404).json({error:"Internship not found."});
  const {data,errors}=validateApplication(req.body);
  if(Object.keys(errors).length) return res.status(422).json({error:"Validation failed.",fields:errors});
  const result=db.prepare(`INSERT INTO applications
    (internship_id,name,email,phone,cover_letter) VALUES (?,?,?,?,?)`)
    .run(internshipId,data.name,data.email,data.phone,data.coverLetter);
  res.status(201).json({message:"Application submitted successfully.",id:result.lastInsertRowid});
});

app.use((err,req,res,next)=>{
  console.error(err);
  res.status(500).json({error:"Internal server error."});
});

const port=process.env.PORT || 3000;
if (process.env.NODE_ENV !== "test") app.listen(port,()=>console.log(`Server running at http://localhost:${port}`));
export { app, db, validateApplication };
