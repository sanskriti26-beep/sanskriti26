# Secure Internship Board Integration

Full-stack internship portal using Express, SQLite, and vanilla JavaScript.

## Features
- Frontend loads internship records from REST API.
- Loading, retry, failure, and empty states.
- Search, domain, and location filters.
- Application modal with client-side and server-side validation.
- SQLite persistence for internships and applications.
- Helmet security headers.
- API rate limiting.
- Parameterized SQL queries.
- Automated validation tests.

## Run
```bash
npm install
npm start
```
Open `http://localhost:3000`.

## Test
```bash
npm test
```

## API examples
```bash
curl http://localhost:3000/api/internships
curl "http://localhost:3000/api/internships?search=frontend&domain=Web%20Development"
```

## Screenshots
Add `screenshots/desktop.png`, `screenshots/mobile.png`, and `screenshots/application-form.png` after testing locally.

## Deployment
Deploy to a Node-compatible host such as Render, Railway, or Fly.io. Set the start command to `npm start`.

## Submission
Submit the public repository or deployed preview URL.
