# Responsive Internship Board

A responsive, accessible internship listing interface built without a framework.

## Features
- Semantic HTML5 structure
- Responsive mobile, tablet, and desktop layouts
- Search by title, company, or domain
- Domain and location filters
- Dynamic DOM rendering from JSON data
- Loading, error, and empty states
- Keyboard-friendly controls and visible focus styles
- Accessible labels and descriptive application links

## Run locally
Because the project loads JSON with `fetch()`, use a local server.

### VS Code
1. Open this folder in Visual Studio Code.
2. Install the **Live Server** extension.
3. Right-click `index.html`.
4. Select **Open with Live Server**.

## Deploy with GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, `internships.json`, and `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/root`.
6. Save and open the generated public URL.

## Screenshots
Add screenshots in the `screenshots/` folder and reference them here:

```md
![Desktop view](screenshots/desktop.png)
![Mobile view](screenshots/mobile.png)
```

## Submission
Submit either the public GitHub repository URL or the deployed GitHub Pages URL.
