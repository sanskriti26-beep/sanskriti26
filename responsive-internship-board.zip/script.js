const list = document.querySelector("#internshipList");
const searchForm = document.querySelector("#searchForm");
const searchInput = document.querySelector("#searchInput");
const domainFilter = document.querySelector("#domainFilter");
const locationFilter = document.querySelector("#locationFilter");
const clearButton = document.querySelector("#clearButton");
const retryButton = document.querySelector("#retryButton");
const loading = document.querySelector("#loading");
const errorMessage = document.querySelector("#errorMessage");
const emptyMessage = document.querySelector("#emptyMessage");
const resultCount = document.querySelector("#resultCount");

let internships = [];

async function loadInternships() {
  loading.hidden = false;
  errorMessage.hidden = true;
  list.innerHTML = "";
  try {
    const response = await fetch("internships.json");
    if (!response.ok) throw new Error("Could not load data");
    internships = await response.json();
    populateFilters();
    renderInternships(internships);
  } catch (error) {
    console.error(error);
    errorMessage.hidden = false;
    resultCount.textContent = "";
  } finally {
    loading.hidden = true;
  }
}

function populateFilters() {
  const domains = [...new Set(internships.map(item => item.domain))].sort();
  const locations = [...new Set(internships.map(item => item.location))].sort();
  domains.forEach(value => addOption(domainFilter, value));
  locations.forEach(value => addOption(locationFilter, value));
}
function addOption(select, value) {
  const option = document.createElement("option");
  option.value = value;
  option.textContent = value;
  select.appendChild(option);
}
function initials(company) {
  return company.split(" ").map(word => word[0]).join("").slice(0, 2).toUpperCase();
}
function safe(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}
function renderInternships(items) {
  list.innerHTML = "";
  resultCount.textContent = `${items.length} ${items.length === 1 ? "internship" : "internships"} found`;
  emptyMessage.hidden = items.length !== 0;
  items.forEach(item => {
    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <div class="card-top">
        <div class="logo" aria-hidden="true">${safe(initials(item.company))}</div>
        <span class="badge">${safe(item.type)}</span>
      </div>
      <h3>${safe(item.title)}</h3>
      <p class="company">${safe(item.company)}</p>
      <div class="tags">
        <span class="tag">${safe(item.domain)}</span>
        <span class="tag">${safe(item.duration)}</span>
      </div>
      <div class="card-bottom">
        <span class="location">${safe(item.location)}</span>
        <a class="apply-link" href="${safe(item.applyUrl)}" target="_blank" rel="noopener noreferrer"
           aria-label="Apply for ${safe(item.title)} at ${safe(item.company)}">View details →</a>
      </div>`;
    list.appendChild(card);
  });
}
function filterInternships() {
  const term = searchInput.value.trim().toLowerCase();
  const domain = domainFilter.value;
  const location = locationFilter.value;
  const filtered = internships.filter(item => {
    const textMatch = `${item.title} ${item.company} ${item.domain}`.toLowerCase().includes(term);
    return textMatch && (domain === "all" || item.domain === domain) &&
      (location === "all" || item.location === location);
  });
  renderInternships(filtered);
}
searchForm.addEventListener("submit", event => { event.preventDefault(); filterInternships(); });
domainFilter.addEventListener("change", filterInternships);
locationFilter.addEventListener("change", filterInternships);
clearButton.addEventListener("click", () => {
  searchInput.value = "";
  domainFilter.value = "all";
  locationFilter.value = "all";
  renderInternships(internships);
});
retryButton.addEventListener("click", loadInternships);
loadInternships();
